#include<stdio.h>
#include<string.h>
#include<stdlib.h>

void menu(){
	printf("Bluejack GShop \n");
	printf("=======================\n");
	printf("1. Insert \n");
	printf("2. View Game \n");
	printf("3. Update Stock \n");
	printf("4. Exit \n");
	printf(">> ");
}

struct Game{
	char name[100];
	char type[100];
	int stock;
	
	struct Game* left;
	struct Game* right;
	int height;
};


struct Game* new_node(char name[], char type[], int stock){
	struct Game* game = (struct Game*) malloc(sizeof(struct Game));
	
	strcpy(game->name, name);
	strcpy(game->type, type);
	game->stock = stock;
	
	game->left = NULL;
	game->right = NULL;
	game->height = 1;
	
	return game;
}


int max(int a, int b){
	return (a>b)?a:b;
}

int height(struct Game* node){
	if(node == NULL){
		return 0;
	}
	return node->height;
}

int get_balance(struct Game* node){
	if(node == NULL){
		return 0;
	}
	return height(node->left) - height(node->right);
}

struct Game* right_rotate(struct Game* node){
	struct Game* x = node->left;
	struct Game* sub_x = x->right;
	
	x->right = node;
	node->left = sub_x;
	
	node->height = max(height(node->left), height(node->right));
	x->height = max(height(x->left), height(x->right));
	
	return x;
}

struct Game* left_rotate(struct Game* node){
	struct Game* x = node->right;
	struct Game* sub_x = x->left;
	
	x->left = node;
	node->right = sub_x;
	
	node->height = max(height(node->left), height(node->right));
	x->height = max(height(x->left), height(x->right));
	
	return x;
}


int check_type_Action(char type[]){
	int checkers;
	checkers = strcmp(type, "Action");
	
	return checkers;
}

int check_type_CardGame(char type[]){
	int checkers;
	checkers = strcmp(type, "Card Game");
	
	return checkers;
}

int check_type_RPG(char type[]){
	int checkers;
	checkers = strcmp(type, "RPG");
	
	return checkers;
}

int check_type_Adventure(char type[]){
	int checkers;
	checkers = strcmp(type, "Adventure");
	
	return checkers;
}

struct Game* insert(struct Game* node, char* name, char* type, int stock){
	if(node == NULL){
		return new_node(name, type, stock);
	}
	if(stock < node->stock){
		node->left = insert(node->left, name, type, stock);
	}
	else if(stock > node->stock){
		node->right = insert(node->right, name, type, stock);
	}
	else{
		return node;
	}
	
	node->height = 1 + max(height(node->left), height(node->right));
	
	int balance = get_balance(node);
	
	//left left case
	if(balance > 1 && stock < node->left->stock){
		//right rotate
		return right_rotate(node);
	} 
	//Left right case
	if(balance > 1 && stock > node->left->stock){
		//left rotate
		node->left = left_rotate(node->left);
		//right rotate
		return right_rotate(node);
	}
	//right right case
	if(balance < -1 && stock > node->right->stock){
		//left rotate
		return left_rotate(node);
	}
	//right left case
	if(balance < -1 && stock < node->right->stock){
		//right rotate
		node->right = right_rotate(node->right);
		//left rotate
		return left_rotate(node);
	}
	return node;
}

void pre_order(struct Game* node){
	if(node != NULL){
		printf("%s - %s - %d\n", node->name, node->type, node->stock);
		pre_order(node->left);
		pre_order(node->right);
	}
	else{
		printf("Still empty ! \n");
	}
}

int main (){
	struct Game* root = NULL;
	
	insert(root, "Dota 2", "Adventure", 3);
	
	int choose, len, stock, tambahan;
	char name[100], type[100], inputan[20];
	int checker1, checker2, checker3, checker4;
	do{
		do{
			menu();
			scanf("%d", &choose); getchar();
			if(choose < 1 || choose > 4){
				printf("Pilihan salah, silahkan pilih lagi\n\n");
			}
		}while(choose < 1 || choose > 4);
		
		switch(choose){
				case 1:
					do{
						printf("Input game title [5-25][unique]: ");
						scanf("%[^\n]", &name); getchar();
						len = strlen(name);		
					}while(len < 5 || len > 25);
					
					do{
						printf("Input game type[Action|RPG|Adventure|Card Game]: ");
						scanf("%[^\n]", type); getchar();
						
						checker1 = check_type_Action(type);
						checker2 = check_type_RPG(type);
						checker3 = check_type_Adventure(type);
						checker4 = check_type_CardGame(type);
						
					}while(checker1 != 0 && checker2 != 0 && checker3 != 0 && checker4 != 0);
					
					do{
						printf("Input game stock[>=1]: ");
						scanf("%d", &stock); getchar();
					}while(stock < 1);
					
					
					insert(root, name, type, stock);
					printf("%s - %s - %d\n", name, type, stock);
					printf("Insert Success !\n");
					break;
				case 2:
					pre_order(root);
					break;
				case 3:
					printf("Input game title: ");
					scanf("%[^\n]", name); getchar();
					do{
						printf("add or remove: ");
						scanf("%s", &inputan);	
					}while(strcmp(inputan,"add") != 0 && strcmp(inputan,"remove")!=0);
					
					if (inputan == "add"){
						printf("How many stock you want add : ");
						scanf("%d", &tambahan); getchar();
						stock += tambahan;
					}
					else if(inputan == "remove"){
						printf("How many stock you want remove : ");
						scanf("%d", &tambahan); getchar();
						stock -= tambahan;
					}
					break;
				case 4:
					break;
			}
			
	}while(choose != 4);
	return 0;
}
